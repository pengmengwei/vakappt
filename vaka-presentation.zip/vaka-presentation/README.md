# vaka 知识助手 — 演示文稿

## 快速部署到 Vercel（3 种方式）

### 方式一：直接拖拽（最快，无需命令行）
1. 打开 [vercel.com](https://vercel.com) 并登录
2. 点击 Dashboard → **Add New...** → **Project**
3. 选择 **Import Git Repository** 下方的 **"Upload a folder"**（或直接将本文件夹拖拽到 Vercel 导入界面）
4. 框架预设选择 **Other**（静态网站）
5. 点击 **Deploy**，约 10 秒后获得在线链接

### 方式二：通过 GitHub 部署（推荐，便于后续更新）
1. 在 GitHub 新建一个仓库（如 `vaka-presentation`）
2. 将本文件夹内所有文件上传至该仓库根目录
3. 在 Vercel 点击 **Add New Project** → 选择该 GitHub 仓库
4. 框架预设选择 **Other**，点击 **Deploy**
5. 之后每次 push 到 GitHub，Vercel 会自动重新部署

### 方式三：Vercel CLI
```bash
# 安装 CLI（如未安装）
npm i -g vercel

# 进入本项目目录
cd vaka-presentation

# 登录并部署
vercel --prod
```

---

## 替换真实素材

当前 `vaka-assets/` 文件夹内是占位 SVG，请按以下对应关系替换为你的真实图片：

| 占位文件 | 应替换为 | 用途 |
|---------|---------|------|
| `5.2.svg` | `5.2.gif` | 开箱即用演示 |
| `6.2.svg` | `6.2.gif` | 多模态数据解析 |
| `7.2.svg` | `7.2.gif` | 端到端任务执行 |
| `8.2.svg` | `8.2.gif` | 知识进化与记忆 |
| `9.2.svg` | `9.2.gif` | 发现数据 |
| `10.2.svg` | `10.2.gif` | 企业 SSO |
| `扫码直接使用.svg` | `扫码直接使用.png` | 二维码 |
| `飞书交流群.svg` | `飞书交流群.png` | 二维码 |
| `微信交流群.svg` | `微信交流群.png` | 二维码 |

替换后修改 `index.html` 中对应的文件名（将 `.svg` 改回 `.gif` / `.png`），重新部署即可。

---

## 本地预览

直接在浏览器中打开 `index.html` 即可全屏预览，支持键盘方向键翻页。
